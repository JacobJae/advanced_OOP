package eecs2030.lab7;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BinarySearchTree<String> bi = new BinarySearchTree<String>();
		System.out.println(bi.toString());
		bi.add("ggggggg");
		System.out.println(bi.toString());
		bi.add("a");
		System.out.println(bi.toString());
		bi.add("");
		System.out.println(bi.toString());
		bi.add("ccc");
		System.out.println(bi.toString());
		bi.add("bb");
		System.out.println(bi.toString());
		bi.add("eeeee");
		System.out.println(bi.toString());
		bi.add("dddd");
		System.out.println(bi.toString());
		bi.add("ffffff");
		System.out.println(bi.toString());
		bi.add("iiiiiiiii");
		System.out.println(bi.toString());
		bi.add("hhhhhhhh");
		System.out.println(bi.toString());
		bi.add("jjjjjjjjjj");
		System.out.println(bi.toString());
		System.out.println(bi.contains("x"));
		System.out.println(TreeTraversal.preorder(bi));
		System.out.println(TreeTraversal.breadthFirst(bi));
		
	}

}
