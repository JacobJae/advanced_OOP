package eecs2030.lab7;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * A utility class that provides methods for traversing a binary search tree.
 *
 */
public class TreeTraversal {
	private TreeTraversal() {
		// empty by design
	}

	/**
	 * Returns the list of strings formed by traversing the specified tree using an
	 * inorder traversal.
	 * 
	 * @param tree
	 *            a binary search tree
	 * @return the list of strings formed by traversing the specified tree using an
	 *         inorder traversal
	 */
	public static List<String> inorder(BinarySearchTree<String> tree) {
		return TreeTraversal.inorder(tree.root());
		// YOU SHOULD IMPLEMENT inorder(INode) below
	}

	/**
	 * Returns the list of strings formed by traversing the specified tree using a
	 * preorder traversal.
	 * 
	 * @param tree
	 *            a binary search tree
	 * @return the list of strings formed by traversing the specified tree using a
	 *         preorder traversal
	 */
	public static List<String> preorder(BinarySearchTree<String> tree) {
		return TreeTraversal.preorder(tree.root());
		// YOU SHOULD IMPLEMENT preorder(INode) below
	}

	/**
	 * Returns the list of strings formed by traversing the specified tree using a
	 * postorder traversal.
	 * 
	 * @param tree
	 *            a binary search tree
	 * @return the list of strings formed by traversing the specified tree using a
	 *         postorder traversal
	 */
	public static List<String> postorder(BinarySearchTree<String> tree) {
		return TreeTraversal.postorder(tree.root());
		// YOU SHOULD IMPLEMENT postorder(INode) below
	}

	/**
	 * Returns the list of strings formed by traversing the specified tree using a
	 * breadth first traversal. The traversal visits nodes of the tree starting at
	 * the root moving left to right for each level of the tree.
	 * 
	 * @param tree
	 *            a binary search tree
	 * @return the list of strings formed by traversing the specified tree using a
	 *         breadth first traversal
	 */
	public static List<String> breadthFirst(BinarySearchTree<String> tree) {
		List<String> result = new ArrayList<>();
		INode<String> root = tree.root();

		// If the node is null then return.
		if (root == null) {
			return result;
		}

		// Create an empty queue q of nodes.
		// in Java, a LinkedList is a Queue
		// to enqueue a node, use the Queue method add
		// to dequeue a node, use the Queue method remove
		Queue<INode<String>> q = new LinkedList<>();

		// Add the root node to q.
		q.add(root);

		// While q is not empty:
		while (!q.isEmpty()) {
			// Dequeue the node n from the front of q
			INode<String> node = q.poll();
			// Visit n
			result.add(node.data());
			// If n has a left child then enqueue the left child in q
			if (node.left() != null)
				q.add(node.left());
			// If n has a right child then enqueue the right child in q
			if (node.right() != null)
				q.add(node.right());
		}

		return result;
	}

	/**
	 * Returns the list of strings formed by traversing a tree having the specified
	 * root using an inorder traversal.
	 * 
	 * @param root
	 *            the root of the tree
	 * @return the list of strings formed by traversing a tree having the specified
	 *         root using an inorder traversal
	 */
	private static List<String> inorder(INode<String> root) {
		List<String> result = new ArrayList<>();

		// If the node is null then return.
		if (root == null) {
			return result;
		}

		// Recursively perform an in-order traversal of the left child of the node.
		result.addAll(inorder(root.left()));

		// Visit the node.
		result.add(root.data());

		// Recursively perform an in-order traversal of the right child of the node.
		result.addAll(inorder(root.right()));

		return result;
	}

	/**
	 * Returns the list of strings formed by traversing a tree having the specified
	 * root using a preorder traversal.
	 * 
	 * @param root
	 *            the root of the tree
	 * @return the list of strings formed by traversing a tree having the specified
	 *         root using a preorder traversal
	 */
	private static List<String> preorder(INode<String> root) {
		List<String> result = new ArrayList<>();

		// If the node is null then return.
		if (root == null) {
			return result;
		}

		// Visit the node.
		result.add(root.data());

		// Recursively perform an in-order traversal of the left child of the node.
		result.addAll(preorder(root.left()));

		// Recursively perform an in-order traversal of the right child of the node.
		result.addAll(preorder(root.right()));

		return result;
	}

	/**
	 * Returns the list of strings formed by traversing a tree having the specified
	 * root using a postorder traversal.
	 * 
	 * @param root
	 *            the root of the tree
	 * @return the list of strings formed by traversing a tree having the specified
	 *         root using a postorder traversal
	 */
	private static List<String> postorder(INode<String> root) {
		List<String> result = new ArrayList<>();

		// If the node is null then return.
		if (root == null) {
			return result;
		}

		// Recursively perform an in-order traversal of the left child of the node.
		result.addAll(postorder(root.left()));

		// Recursively perform an in-order traversal of the right child of the node.
		result.addAll(postorder(root.right()));

		// Visit the node.
		result.add(root.data());

		return result;
	}

}
