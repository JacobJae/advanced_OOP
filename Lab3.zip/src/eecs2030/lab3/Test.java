package eecs2030.lab3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int max = 100;
		Complex c = new Complex(0.15, 0.58);
		
		Complex z = new Complex(0.0, 0.0);
		Complex comp = ( z.multiply(z) ).add(c);
		int iter = 1;
		while (iter < max && comp.mag() <= 2.0) {
			comp = ( comp.multiply(comp) ).add(c);
			iter++;
		}
		
		System.out.println(iter);
		System.out.println(comp);
		System.out.println(comp.mag());

	}

}
